Just A simple website, just for final submission on dicoding
